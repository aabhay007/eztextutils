# TextUtils

TextUtils is a simple Python package for performing basic text operations.

## Features

- Count words in a text string
- Count characters in a text string (excluding spaces)
- Reverse text

## Installation

```bash
pip install eztextutils
