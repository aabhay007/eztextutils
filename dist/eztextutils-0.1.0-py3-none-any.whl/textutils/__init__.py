# textutils/__init__.py
from .utils import count_words, count_characters, reverse_text
